#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:01:00,ncpus=96,mem=10GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 96 lmp_openmpi -k on -sf kk -i benchmark.in -var x 6 -var y 4 -var z 4 -log 96KKW.log
