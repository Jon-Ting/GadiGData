#!/bin/bash
#PBS -P q27
#PBS -q gpuvolta
#PBS -l walltime=00:00:10,ngpus=1,ncpus=12,mem=6GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

ngpus=$(( PBS_NGPUS<8?PBS_NGPUS:8 ))
echo $ngpus

mpirun -np 12 lmp_openmpi -sf gpu -pk gpu 1 -i benchmark.in -log 1GPU.log -nc
