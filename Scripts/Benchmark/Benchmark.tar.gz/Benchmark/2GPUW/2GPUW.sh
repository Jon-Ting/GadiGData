#!/bin/bash
#PBS -P q27
#PBS -q gpuvolta
#PBS -l walltime=00:01:00,ngpus=2,ncpus=24,mem=4GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 24 lmp_openmpi -sf gpu -pk gpu 2 -i benchmark.in -var x 4 -var y 3 -var z 2 -log 2GPUW.log -nc
