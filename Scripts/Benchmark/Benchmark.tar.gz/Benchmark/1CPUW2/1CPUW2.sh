#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:00:40,ncpus=1,mem=100MB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

# On Raijin, add --bind-to-none after mpirun if NCPUS < 16
mpirun lmp_openmpi -i benchmark.in -var x 2 -var y 2 -var z 1 -log 1CPUW2.log
