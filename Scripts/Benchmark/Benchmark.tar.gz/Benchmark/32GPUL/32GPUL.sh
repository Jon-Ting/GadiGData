#!/bin/bash
#PBS -P q27
#PBS -q gpuvolta
#PBS -l walltime=00:03:00,ngpus=32,ncpus=384,mem=80GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 384 lmp_openmpi -sf gpu -pk gpu 4 -i benchmark.in -var x 3 -var y 2 -var z 2 -log 32GPUL.log -nc
