#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:10:00,ncpus=1,mem=1GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

# On Raijin, add --bind-to-none after mpirun if NCPUS < 16
mpirun lmp_openmpi -i benchmark.in -var x 2 -var y 2 -var z 2 -log 1CPUW3.log
