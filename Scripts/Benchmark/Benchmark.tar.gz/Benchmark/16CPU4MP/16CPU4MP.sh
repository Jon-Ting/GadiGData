#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:00:10,ncpus=16,mem=1600MB,jobfs=1GB,software=lammps
#PBS -l wd

module unload intel-fc intel-cc openmpi
module load openmpi/4.0.2
module load lammps/3Mar2020

n=4
mpirun -map-by ppr:$((8/$n)):socket:PE=$n lmp_openmpi -sf omp -pk omp $n -i benchmark.in -log 16CPU4MP.log
