#!/bin/bash
#PBS -P q27
#PBS -q gpuvolta
#PBS -l walltime=00:01:00,ngpus=4,ncpus=48,mem=6GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 48 lmp_openmpi -sf gpu -pk gpu 4 -i benchmark.in -var x 3 -var y 2 -var z 2 -log 4GPUL.log -nc
