#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:00:10,ncpus=8,mem=800MB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 1 lmp_openmpi -k on -sf kk -i benchmark.in -log 8KK8N.log
