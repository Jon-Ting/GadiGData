#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:00:10,ncpus=32,mem=3200MB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 32 lmp_openmpi -k on -sf kk -i benchmark.in -log 32KK.log
