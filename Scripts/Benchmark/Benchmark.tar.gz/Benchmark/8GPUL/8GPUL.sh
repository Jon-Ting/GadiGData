#!/bin/bash
#PBS -P q27
#PBS -q gpuvolta
#PBS -l walltime=00:02:00,ngpus=8,ncpus=96,mem=30GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 96 lmp_openmpi -sf gpu -pk gpu 4 -i benchmark.in -var x 3 -var y 2 -var z 2 -log 8GPUL.log -nc
