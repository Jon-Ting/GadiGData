#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:00:10,ncpus=1536,mem=153GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 1536 lmp_openmpi -k on -sf kk -i benchmark.in -var x 16 -var y 12 -var z 8 -log 1536KKW.log
