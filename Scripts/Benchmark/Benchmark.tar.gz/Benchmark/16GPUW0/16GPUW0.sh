#!/bin/bash
#PBS -P q27
#PBS -q gpuvolta
#PBS -l walltime=00:01:00,ngpus=16,ncpus=192,mem=160GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 1 lmp_openmpi -sf gpu -pk gpu 16 -i benchmark.in -log 16GPUW0.log -nc
