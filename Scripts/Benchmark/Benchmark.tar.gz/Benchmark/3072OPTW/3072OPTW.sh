#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:01:00,ncpus=3072,mem=400GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

# On Raijin, add --bind-to-none after mpirun if NCPUS < 16
mpirun -np 3072 lmp_openmpi -sf opt -i benchmark.in -var x 16 -var y 16 -var z 12 -log 3072OPTW.log
