#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:00:10,ncpus=8,mem=1000MB,jobfs=1GB,software=lammps
#PBS -l wd

module unload intel-fc intel-cc openmpi
module load openmpi/4.0.2
module load lammps/3Mar2020

n=2
mpirun -map-by ppr:$((8/$n)):socket:PE=$n lmp_openmpi -sf omp -pk omp $n -i benchmark.in -log 8CPU2MP.log
