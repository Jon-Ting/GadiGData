#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:01:00,ncpus=768,mem=80GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

# On Raijin, add --bind-to-none after mpirun if NCPUS < 16
mpirun -np 768 lmp_openmpi -sf opt -i benchmark.in -var x 12 -var y 8 -var z 8 -log 768OPTW.log
