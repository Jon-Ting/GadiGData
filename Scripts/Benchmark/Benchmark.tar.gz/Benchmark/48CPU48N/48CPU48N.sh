#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:00:20,ncpus=48,mem=4800MB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

# On Raijin, add --bind-to-none after mpirun if NCPUS < 16
mpirun -np 1 lmp_openmpi -i benchmark.in -log 48CPU48N.log
