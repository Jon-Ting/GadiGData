#!/bin/bash
#PBS -P q27
#PBS -q gpuvolta
#PBS -l walltime=00:00:20,ngpus=2,ncpus=24,mem=4GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 2 lmp_openmpi -sf gpu -pk gpu 2 -i benchmark.in -log 2GPU12N.log -nc
