#!/bin/bash
#PBS -P q27
#PBS -q normal
#PBS -l walltime=00:01:00,ncpus=3072,mem=400GB,jobfs=1GB,software=lammps
#PBS -l wd

module load lammps/3Mar2020

mpirun -np 3072 lmp_openmpi -k on -sf kk -i benchmark.in -var x 16 -var y 16 -var z 12 -log 3072KKW.log
